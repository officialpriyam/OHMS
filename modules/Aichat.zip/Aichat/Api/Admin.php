<?php
namespace Priyx\Mod\Aichat\Api;

class Admin extends \Api_Abstract
{
    public function get_settings($data)
    {
        return $this->di['mod_service']('aichat')->getSettings();
    }

    public function update_settings($data)
    {
        return $this->di['mod_config_update']('aichat', $data);
    }
}
