<?php
namespace Priyx\Mod\Aichat\Api;

class Guest extends \Api_Abstract
{
    public function chat($data)
    {
        $prompt = $data['prompt'] ?? '';
        $history = $data['history'] ?? [];
        
        if (empty($prompt)) {
            throw new \Exception('Prompt is required');
        }
        
        return $this->di['mod_service']('aichat')->ask($prompt, $history);
    }
}
