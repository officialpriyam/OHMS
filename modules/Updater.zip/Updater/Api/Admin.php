<?php
namespace Priyx\Mod\Updater\Api;

class Admin extends \Api_Abstract
{
    public function get_info($data)
    {
        return $this->di['mod_service']('updater')->getLatestUpdateInfo();
    }

    public function update($data)
    {
        $service = $this->di['mod_service']('updater');
        $info = $service->getLatestUpdateInfo();
        if (!$info || !isset($info['update_url'])) {
            throw new \Exception("Could not fetch update information");
        }

        return $service->applyUpdate($info['update_url']);
    }

    public function create_backup($data)
    {
        return $this->di['mod_service']('updater')->createBackup();
    }
}
