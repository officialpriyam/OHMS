<?php
namespace Priyx\Mod\Updater\Controller;

class Admin implements \Priyx\InjectionAwareInterface
{
    protected $di;

    public function setDi($di)
    {
        $this->di = $di;
    }

    public function getDi()
    {
        return $this->di;
    }

    public function fetchNavigation()
    {
        return [
            'group' => [
                'index' => 600,
                'location' => 'system',
                'label' => 'Settings',
                'class' => 'settings',
            ],
            'sub' => [
                [
                    'location' => 'system',
                    'label' => 'Software Update',
                    'index' => 1600,
                    'uri' => $this->di['url']->adminLink('updater'),
                    'class' => '',
                ],
            ],
        ];
    }

    public function register(\Priyx_App &$app)
    {
        $app->get('/updater', 'get_index', [], get_class($this));
    }

    public function get_index(\Priyx_App $app)
    {
        $this->di['is_admin_logged'];
        return $app->render('mod_updater_index');
    }
}
